import React, { useEffect, useState } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";

export default function List() {
  // State fakultas untuk menyimpan data response API Fakultas
  const [fakultas, setFakultas] = useState([]);

  // Panggil API Fakultas menggunakan useEffect dan axios
  useEffect(() => {
    axios
      .get("http://project-apiif-3-b.vercel.app/api/api/fakultas")
      .then((response) => {
        console.log(response.data);
        setFakultas(response.data.result);
      });
  }, []);

  return (
    <div>
      <h2>List Fakultas</h2>
      <NavLink to="/fakultas/create" className="btn btn-primary mb-3">
        Create
      </NavLink>

      <table className="table table-striped table-hover">
        <thead>
          <tr>
            <th>Nama Fakultas</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {fakultas.map((data) => (
            <tr key={data.id}>
              <td>{data.nama}</td>
              <td></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
