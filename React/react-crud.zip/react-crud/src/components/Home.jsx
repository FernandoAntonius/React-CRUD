export default function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Selamat Datang di React CRUD</p>
    </div>
  );
}
